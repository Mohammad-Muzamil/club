import Loaderimage from "../../src/assets/loader.gif"

const Loading = (props) => {
  
  return (
    <img 
    className="Loader"
    src={Loaderimage} alt="loading..." />
  );
};

export default Loading;

