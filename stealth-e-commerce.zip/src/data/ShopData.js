 
 
export const ShopData = [
    {
        "id": 1,
        "name": "Framed Prints",
        "image": require('../assets/img/Shop/1.png')
    },
    {
        "id": 2,
        "name": "Canvas Prints",
        "image":require('../assets/img/Shop/2.png')
    },
    {
        "id": 3,
        "name": "Art Prints",
        "image":require('../assets/img/Shop/3.png')
    },
    {
        "id": 4,
        "name": "Poster Prints",
        "image":require('../assets/img/Shop/4.png')
    },
    {
        "id": 5,
        "name": "Canvas Prints",
        "image":require('../assets/img/Shop/5.png')
    },
    {
        "id": 6,
        "name": "Art Prints",
        "image":require('../assets/img/Shop/6.png')
    },
    {
        "id": 7,
        "name": "Poster Prints",
        "image":require('../assets/img/Shop/7.png')
    }
]

export const ShopData2 = [
    {
        "id": 1,
        "name": "Framed Prints",
        "image": require('../assets/img/Shop/8.png')
    },
    {
        "id": 2,
        "name": "Canvas Prints",
        "image":require('../assets/img/Shop/9.png')
    },
    {
        "id": 3,
        "name": "Art Prints",
        "image":require('../assets/img/Shop/10.png')
    },
    {
        "id": 4,
        "name": "Poster Prints",
        "image":require('../assets/img/Shop/11.png')
    },


]
