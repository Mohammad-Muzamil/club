 
 
 const HomeData = [
    {
        "id": 1,
        "name": "Framed Prints",
        "image": require('../assets/img/product/HomeProduct/1.png')
    },
    {
        "id": 2,
        "name": "Canvas Prints",
        "image":require('../assets/img/product/HomeProduct/2.png')
    },
    {
        "id": 3,
        "name": "Art Prints",
        "image":require('../assets/img/product/HomeProduct/3.png')
    },
    {
        "id": 4,
        "name": "Poster Prints",
        "image":require('../assets/img/product/HomeProduct/4.png')
    }
]

export default HomeData;