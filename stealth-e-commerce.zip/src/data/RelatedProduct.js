
 
 
 const ProductData = [
    {
        "id": 1,
        "name": "Product 1",
        "image": require('../assets/img/product/ProductData/1.png')
    },
    {
        "id": 2,
        "name": "Product 2",
        "image":require('../assets/img/product/ProductData/3.png')
    },
    {
        "id": 3,
        "name": "Product 3",
        "image":require('../assets/img/product/ProductData/2.png')
    },
    {
        "id": 4,
        "name": "Product 4",
        "image": require('../assets/img/product/ProductData/1.png')
    },
   
]

export default ProductData;